# idAthena
[![Build Status](https://travis-ci.org/idathena/trunk.svg?branch=master)](https://travis-ci.org/idathena/trunk) ![license](https://img.shields.io/github/license/idathena/trunk.svg)
[![Total alerts](https://img.shields.io/lgtm/alerts/g/idathena/trunk.svg?logo=lgtm&logoWidth=18)](https://lgtm.com/projects/g/idathena/trunk/alerts/)
[![Language grade: C/C++](https://img.shields.io/lgtm/grade/cpp/g/idathena/trunk.svg?logo=lgtm&logoWidth=18)](https://lgtm.com/projects/g/idathena/trunk/context:cpp)

## Credits
- [rAthena](https://github.com/rathena/rathena)
- [3CeAM](https://github.com/3CeAM/3CeAM)
- [Hercules](https://github.com/HerculesWS/Hercules)
